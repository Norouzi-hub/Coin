const {chromium} = require('./lib').pw;
const T0=require('./lib').tehranAfternoon();   // ساعت ثابت: نتیجه به ساعت اجرای تست بستگی ندارد
const D=h=>new Date(T0-h*3600e3).toISOString();
const posts=[
 {n:960,h:1,t:'#بیت_کوین لانگ<br>ورود ۶۵۰۰۰<br>حد ضرر ۶۳۵۰۰<br>تارگت ۶۹۰۰۰'},
 {n:959,h:2,t:'خبر فوری: #بیت_کوین به ۶۵۰۰۰ رسید؛ هدف بعدی ۷۰۰۰۰ است'},
 {n:958,h:30,t:'تارگت ۲ #سولانا زده شد ✅ سیو سود کنید'},
 {n:957,h:50,t:'ثبت نام در کمپین: روی لینک عضویت کلیک کنید.'},
 {n:956,h:30,t:'#اتریوم شورت<br>ورود ۳۰۰۰<br>حد ضرر ۳۱۰۰'},
 {n:955,h:24*10,t:'صبح بخیر دوستان، امروز بازار آرومه'},
];
const html=`<html><body>${posts.map(p=>`<div class="tgme_widget_message" data-post="c/1893051/${p.n}"><div class="tgme_widget_message_bubble"><div class="tgme_widget_message_text">${p.t}</div><time datetime="${D(p.h)}"></time></div></div>`).join('')}</body></html>`;
let bad=0;const ok=(c,m)=>{if(!c)bad++;console.log('  '+(c?'✅':'❌')+' '+m);};
(async()=>{
 const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:1000}});const p=await ctx.newPage();
 p.on('pageerror',e=>{bad++;console.log('PAGEERROR:',e.message)});p.on('dialog',d=>d.accept());
 await ctx.route('**',r=>{const u=r.request().url();
  if(u.includes('localhost:8899'))return r.continue();
  if(u.includes('t.me/s/'))return r.fulfill({status:200,headers:{'content-type':'text/html','access-control-allow-origin':'*'},body:html});
  return r.abort();});
 await p.clock.install({time:T0});   // ساعت مرورگر هم همان لحظه
 await p.goto('http://localhost:8899/index.html',{waitUntil:'domcontentloaded'});
 await p.waitForTimeout(3000);
 await p.evaluate(()=>{ACCOPEN=null;});
 const ids=async()=>p.$$eval('#list .card',e=>e.map(c=>c.dataset.id.split('/').pop()).join(','));
 const clickFc=async(txt,sel='#fbar .fc')=>{await p.$$eval(sel,(bs,t)=>{const x=bs.find(b=>b.textContent.includes(t));if(!x)throw new Error('no chip '+t);x.click();},txt);await p.waitForTimeout(150);};
 console.log('=== «همه» = سیگنال‌ها و نتیجه‌ها؛ بقیه در آرشیو ===');
 await p.$$eval('#fbar .fb:not(.fday)',bs=>bs.find(b=>b.textContent.includes('همه')).click());
 await p.waitForTimeout(150);
 ok(await p.$$eval('#fbar .frow .fc',r=>r.length)===0&&await p.$$eval('#fbar .fday select',r=>r.length)===1,'ردیف چیپ نوع برداشته شد؛ انتخاب‌گر روز هست');
 ok(await ids()==='960,958,956','همه: '+await ids());
 await p.$$eval('#fbar .fbucket',bs=>bs.find(b=>b.textContent.includes('آرشیو')).click());await p.waitForTimeout(150);
 ok(await ids()==='959,957,955','آرشیو: خبر، اطلاع‌رسانی، یادداشت: '+await ids());
 await p.$$eval('#fbar .fbucket',bs=>bs.find(b=>b.textContent.includes('آرشیو')).click());await p.waitForTimeout(150);
 console.log('=== فیلتر روز ===');
 await p.selectOption('#fbar .fday select','today');await p.waitForTimeout(150);
 ok(await ids()==='960','امروز: '+await ids());
 await p.selectOption('#fbar .fday select','yest');await p.waitForTimeout(150);
 ok(await ids()==='958,956','دیروز: '+await ids());
 await p.selectOption('#fbar .fday select','week');await p.waitForTimeout(150);
 ok(await ids()==='960,958,956','7 روز: '+await ids());
 await p.selectOption('#fbar .fday select','range');await p.waitForTimeout(150);
 ok(await p.$$eval('#fbar .frange input',e=>e.length)===2,'بازه: دو ورودی تاریخ');
 const d2=new Date(T0-2*864e5), d0=new Date(T0-864e5);
 const iso=d=>d.toLocaleDateString('en-CA',{timeZone:'Asia/Tehran'});
 await p.fill('#fbar .frange label:nth-child(1) input',iso(d2));
 await p.$eval('#fbar .frange label:nth-child(1) input',i=>i.dispatchEvent(new Event('change')));
 await p.fill('#fbar .frange label:nth-child(2) input',iso(d0));
 await p.$eval('#fbar .frange label:nth-child(2) input',i=>i.dispatchEvent(new Event('change')));
 await p.waitForTimeout(150);
 ok(await ids()==='958,956','بازه‌ی پریروز تا دیروز: '+await ids());
 console.log('=== ماندگاری ===');
 await p.reload({waitUntil:'domcontentloaded'});await p.waitForTimeout(2500);
 ok(await ids()==='958,956','بعد از بارگذاری دوباره همان بازه و همان «همه»: '+await ids());
 await p.selectOption('#fbar .fday select','all');await p.waitForTimeout(150);
 console.log('=== دسته‌های دلخواه برداشته شد ===');
 await p.evaluate(()=>{S.feat.accordion=false;renderSignals();});
 const tray=await p.$$eval('#list .card[data-id$="/958"] .ftray .fchip',e=>e.map(x=>x.textContent));
 ok(tray.length===3&&!tray.includes('دسته'),'۳ کلید زیر پست (آرشیو، نتیجه، آموزش): '+tray);
 ok(await p.$$eval('#fbar .fc.add,#fbar .fsep',e=>e.length)===0,'نوار فیلتر بدون دسته');
 console.log(bad?'✗'+bad:'✔ همه درست');
 await b.close();
})();
